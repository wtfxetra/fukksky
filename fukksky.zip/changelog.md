### v1.0 - 7.9.2025
* Initial release