### v1.0.0 - 7.9.2025
* Initial release
### v1.0.1 - 21.9.2025
* Improved code
* New ZRAM logic
* Disabled IOStats